package removeIt;

public class RemoverRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IteratorRemover rem = new IteratorRemover();
		rem.Iterate();
	}

}
