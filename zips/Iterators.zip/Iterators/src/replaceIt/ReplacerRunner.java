package replaceIt;

public class ReplacerRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IteratorReplacer rep = new IteratorReplacer();
		rep.Replace();
	}

}
